./clean.sh
./build.sh quick