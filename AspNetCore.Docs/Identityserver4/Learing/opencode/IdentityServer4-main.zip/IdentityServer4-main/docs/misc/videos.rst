Videos
======
2020
^^^^
* `January [NDC London] -- Implementing OpenID Connect and OAuth 2.0 – Tips from the Trenches  <https://www.youtube.com/watch?v=QpkVnB-N20c>`_
* `January [NDC London] -- OpenID Connect & OAuth 2.0 – Security Best Practices  <https://www.youtube.com/watch?v=AUgZffkurK0>`_

2019
^^^^
* `October [TDC] -- Securing Web Applications and APIs with ASP.NET Core 3.0  <https://vimeo.com/369311388>`_
* `January [NDC] -- Securing Web Applications and APIs with ASP.NET Core 2.2 and 3.0  <https://www.youtube.com/watch?v=EYk3KTwwbFA>`_
* `January [NDC] -- Building Clients for OpenID Connect/OAuth 2-based Systems  <https://www.youtube.com/watch?v=BM091_OlX3o>`_

2018
^^^^
* `26/09 [DevConf] -- Authorization for modern Applications <https://www.youtube.com/watch?v=Dlrf85NTuAU&feature=youtu.be>`_
* `17/01 [NDC London] -- IdentityServer v2 on ASP.NET Core v2 - an Update <https://vimeo.com/254635632>`_
* `17/01 [NDC London] -- Implementing authorization for web apps and APIs (aka PolicyServer announcement) <https://vimeo.com/254635640>`_
* `17/01 [DotNetRocks] -- IdentityServer and PolicyServer on DotNetRocks <https://dotnetrocks.com/?show=1515>`_

2017
^^^^
* `14/09 [Microsoft Learning] -- Introduction to IdentityServer for ASP.NET Core - Brock Allen <https://mva.microsoft.com/en-US/training-courses/introduction-to-identityserver-for-aspnet-core-17945>`_
* `14/06 [NDC Oslo] -- Implementing Authorization for Web Applications and APIs <https://vimeo.com/223982185>`_
* `22/02 [NDC Mini Copenhagen] -- IdentityServer4: New & Improved for ASP.NET Core - Dominick Baier <https://vimeo.com/215352044>`_
* `02/02 [DotNetRocks] -- IdentityServer4 on DotNetRocks <https://www.dotnetrocks.com/?show=1409>`_
* `16/01 [NDC London] -- IdentityServer4: New and Improved for ASP.NET Core <https://vimeo.com/204141878>`_
* `16/01 [NDC London] -- Building JavaScript and mobile/native Clients for Token-based Architectures <https://vimeo.com/205451987>`_

2016
^^^^
* `The history of .NET identity and IdentityServer Channel9 interview <https://channel9.msdn.com/events/Seth-on-the-Road/NDC-London-2016/Dominick-Baier-on-Identity-Server>`_ 
* `Authentication & secure API access for native & mobile Applications - Dominick Baier <https://vimeo.com/171942749>`_
* `ASP.NET Identity 3 - Brock Allen <https://vimeo.com/172009501>`_
* `Introduction to IdentityServer3 - Brock Allen <https://vimeo.com/154172925>`_

2015
^^^^
* `Securing Web APIs – Patterns & Anti-Patterns - Dominick Baier <https://vimeo.com/131635255>`_
* `Authentication and authorization in modern JavaScript web applications – how hard can it be? - Brock Allen <https://vimeo.com/131636653>`_

2014
^^^^
* `Unifying Authentication & Delegated API Access for Mobile, Web and the Desktop with OpenID Connect and OAuth 2 - Dominick Baier <https://vimeo.com/113604459>`_
