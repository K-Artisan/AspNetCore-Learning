git clean -xdf -e samples -e src/IdentityServer4/.vs -e .idea

./clean_cache.sh