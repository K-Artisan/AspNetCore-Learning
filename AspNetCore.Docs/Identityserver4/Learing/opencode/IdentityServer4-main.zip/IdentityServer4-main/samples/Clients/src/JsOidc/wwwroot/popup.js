﻿var mgr = new Oidc.UserManager();
mgr.signinPopupCallback();
