import { Component } from '@angular/core';

@Component({
    selector: 'access-forbidden',
    templateUrl: './access-forbidden.component.html',
    styleUrls: ['./access-forbidden.component.css']
})
export class AccessForbiddenComponent {
}
